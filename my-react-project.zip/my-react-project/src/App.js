import React, {Component} from 'react'
import './App.css'
import { Provider } from 'react-redux'
import store from './redux/store'
import PhotosListContainer from './photosList'

export default class App extends Component {
    constructor(props) {
        super(props);
    }
   
    render() {
        return (
            <Provider store={store}>
                <div>
                    <PhotosListContainer />
                </div>
            </Provider>
        )
    }
}