import React, { useEffect, Component } from 'react'
import { connect } from 'react-redux'
import { fetchPhotos } from './redux'
import ReactPaginate from 'react-paginate';

class PhotosListContainer extends Component {
    
    constructor(props) {
        super(props);
        this.handlePageClick = this
            .handlePageClick
            .bind(this);
        
        this.state = {
            renderData : this.props.photoData.PhotosData.length > 0 ? this.props.photoData.PhotosData : []
        }
    }
        
    handlePageClick = (e) => {
        const selectedPage = e.selected;
        this.props.fetchPhotos(selectedPage)
        this.setState({renderData : this.props.photoData.PhotosData })  
    };

    componentDidMount() {
        this.props.fetchPhotos()
        setTimeout(() => {
            this.setState(
                {renderData : this.props.photoData.PhotosData }
            )
        }, 500);
        
    }

    removeRow = (rowId) => {
        const arrayCopy = this.state.renderData.filter((row) => row.id !== rowId);
        this.setState({renderData: arrayCopy});
    };

    dummyId = 5
    addNewRow = () => {
        this.dummyId++
        let getStateRenderData = this.state.renderData;
        getStateRenderData.push({
            albumId: this.dummyId,
            id: this.dummyId,
            thumbnailUrl: "https://via.placeholder.com/150/771796",
            title: `New row Title added ${this.dummyId}`,
            url: "https://via.placeholder.com/600/771796"
        })
        this.setState({renderData: getStateRenderData});
    }

    render() {
        return (
                <div>
                    { this.props.photoData.loading ? (
                        <h2>Loading</h2>
                    ) : this.props.photoData.error ? (
                        <h2>{this.props.photoData.error}</h2>
                    ) : (
                            <div>
                            <h2>Photos List</h2> 
                            <div> 
                                <ul className="photos_ul">
                                    {this.state.renderData.length > 0  ? this.state.renderData.map(item => (
                                        <li key={item.id}>
                                            <a href={item.url}>
                                                <div><img src={item.thumbnailUrl} height="50px" width="50px"/></div>
                                                <div>{item.title}</div>
                                                
                                            </a>
                                            <div><button type="button"  onClick={() => this.removeRow(item.id)}>Delete row</button></div>
                                        </li>
                                    )): ''} 
                                    
                                    {this.state.renderData.length > 0 &&
                                        <li className="add-btn"> 
                                            <button type="button" onClick={() => this.addNewRow()}>Add New Row</button>
                                        </li>
                                    }
                                    
                                </ul>
                            </div>
                        
                            </div>
                        )
                    }

                        <ReactPaginate
                            previousLabel={"prev"}
                            nextLabel={"next"}
                            breakLabel={"..."}
                            breakClassName={"break-me"}
                            pageCount={100}
                            marginPagesDisplayed={2}
                            pageRangeDisplayed={5}
                            onPageChange={this.handlePageClick}
                            containerClassName={"pagination"}
                            subContainerClassName={"pages pagination"}
                            activeClassName={"active"}/>

                                    
                </div>
                                
            ) 
            
    }
    
  
}

const mapStateToProps = state => {
  return {
    photoData: state.photosData
  }
}

const mapDispatchToProps = dispatch => {
  return {
    fetchPhotos: (selectedPage) => dispatch(fetchPhotos(selectedPage))
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(React.memo(PhotosListContainer))