import axios from 'axios'
import {
  FETCH_PHOTOS_REQUEST,
  FETCH_PHOTOS_SUCCESS,
  FETCH_PHOTOS_FAILURE
} from './photos.type'

export const fetchPhotos = (selectedPage = 0) => {
  return (dispatch) => {
    dispatch(fetchPhotosRequest())
    axios
      .get(`http://jsonplaceholder.typicode.com/photos?_start=${selectedPage}&_limit=5`)
      .then(response => {
        const photoDatas = response.data
        dispatch(fetchPhotosSuccess(photoDatas))
      })
      .catch(error => {
        dispatch(fetchPhotosFailure(error.message))
      })
  }
}

export const fetchPhotosRequest = () => {
  return {
    type: FETCH_PHOTOS_REQUEST
  }
}

export const fetchPhotosSuccess = photoDatas => {
  return {
    type: FETCH_PHOTOS_SUCCESS,
    payload: photoDatas
  }
}

export const fetchPhotosFailure = error => {
  return {
    type: FETCH_PHOTOS_FAILURE,
    payload: error
  }
}
