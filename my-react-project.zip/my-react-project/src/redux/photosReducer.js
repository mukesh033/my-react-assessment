import {
    FETCH_PHOTOS_REQUEST,
    FETCH_PHOTOS_SUCCESS,
    FETCH_PHOTOS_FAILURE
  } from './photos.type'
  
  const initialState = {
    loading: false,
    PhotosData: [],
    error: ''
  }
  
  const reducer = (state = initialState, action) => {      
    switch (action.type) {
      case FETCH_PHOTOS_REQUEST:
        return {
          ...state,
          loading: true
        }
      case FETCH_PHOTOS_SUCCESS:
        return  Object.assign({}, state, {
            loading: false,
            PhotosData: action.payload,
            error: ''
        });
        
      case FETCH_PHOTOS_FAILURE:
       
        return  Object.assign({}, state, {
            loading: false,
            PhotosData: [],
            error: action.payload
        });
      default: return state
    }

  }
  
  export default reducer