import { combineReducers } from 'redux'
import photosReducer from './photosReducer'

const rootReducer = combineReducers({
  photosData: photosReducer
})

export default rootReducer